package words;

import java.io.IOException;
public class Main {
	//public static String[] read=null;
	//TODO: make plural and singular nouns seperat.
	public static void main(String[] args) throws InterruptedException, IOException {
		System.out.println(words.Read_Write.structure("walk the dog"));

}
}
			
			 
			 
			 
			 
			 
			 
			 
			


